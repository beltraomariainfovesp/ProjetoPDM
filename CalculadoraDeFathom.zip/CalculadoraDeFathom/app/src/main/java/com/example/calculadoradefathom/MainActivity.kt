package com.example.calculadoradefathom

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.calculadoradefathom.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = ActivityMainBinding.inflate( layoutInflater)
        setContentView(binding.root)

        binding.idButton.setOnClickListener { view ->
            val fathom = binding.idFathom.text.toString().replace(",", ".").toDouble()
            val metros = fathom * 1.828
            val metrosArredondado = "%.3f".format(metros).replace(".", ",")
            binding.idDivas.text = "A conversão de Fathom para Metros é $metrosArredondado ^o^"
        }
    }
}